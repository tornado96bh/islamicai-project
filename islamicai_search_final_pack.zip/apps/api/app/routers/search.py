from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from apps.api.app.deps import db_session
from packages.services.search import SearchService

router = APIRouter()

@router.get("")
def search(
    q: str = Query(..., min_length=1),
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    db: Session = Depends(db_session),
):
    return SearchService(db).search(query=q, limit=limit, offset=offset)
