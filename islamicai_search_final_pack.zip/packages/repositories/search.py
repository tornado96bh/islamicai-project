from __future__ import annotations

from sqlalchemy.orm import Session

from packages.search.engine import SearchEngine

class SearchRepository:
    def __init__(self, db: Session):
        self.engine = SearchEngine(db)

    def search(self, query: str, limit: int = 20, offset: int = 0):
        return self.engine.search(query=query, limit=limit, offset=offset)
