from __future__ import annotations

from sqlalchemy import desc, func, select
from sqlalchemy.orm import Session, joinedload

from packages.database.models import Edition, Page, PageElement, Volume
from packages.learning.dictionary import search_form_text

from .models import build_element_hit, hit_key

DIACRITICS = "\u064B\u064C\u064D\u064E\u064F\u0650\u0651\u0652\u0670\u0640"

def _sql_search_form(column):
    return func.translate(func.coalesce(column, ""), DIACRITICS, "")

class FuzzySearcher:
    def __init__(self, db: Session):
        self.db = db

    def search(self, query: str, limit: int = 20) -> list[dict]:
        q = search_form_text(query)
        if not q:
            return []

        text_expr = _sql_search_form(PageElement.text)
        score_expr = func.greatest(
            func.similarity(text_expr, q),
            func.word_similarity(text_expr, q),
        ).label("score")

        stmt = (
            select(PageElement, score_expr)
            .options(
                joinedload(PageElement.page)
                .joinedload(Page.volume)
                .joinedload(Volume.edition)
                .joinedload(Edition.book)
            )
            .where(score_expr >= 0.18)
            .order_by(desc(score_expr), PageElement.page_id, PageElement.element_order)
            .limit(limit)
        )

        hits: list[dict] = []
        seen: set[str] = set()
        for element, score in self.db.execute(stmt).all():
            hit = build_element_hit(element, float(score or 0.0), "fuzzy", "trigram")
            key = hit_key(hit)
            if key in seen:
                continue
            seen.add(key)
            hits.append(hit)
        return hits

    def search_many(self, queries: list[str], limit: int = 20) -> list[dict]:
        out: list[dict] = []
        seen: set[str] = set()
        for query in queries:
            for hit in self.search(query, limit=max(limit, 20)):
                key = hit_key(hit)
                if key in seen:
                    continue
                seen.add(key)
                out.append(hit)
        return out
