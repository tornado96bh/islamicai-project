from __future__ import annotations

from dataclasses import dataclass
import re

from packages.learning.dictionary import normalize_surface_text, search_form_text, tokenize_text

@dataclass(slots=True)
class SearchQuery:
    original: str
    normalized: str
    search_form: str
    tokens: list[str]
    search_tokens: list[str]
    phrases: list[str]

class QueryProcessor:
    def process(self, query: str) -> SearchQuery:
        original = (query or "").strip()
        normalized = normalize_surface_text(original)
        search_form = search_form_text(original)
        tokens = tokenize_text(normalized)
        search_tokens = tokenize_text(search_form)

        phrases: list[str] = []
        if search_form:
            phrases.append(search_form)

        def ngrams(items: list[str], start: int, stop: int) -> list[str]:
            out: list[str] = []
            upper = min(stop, len(items))
            for n in range(start, upper + 1):
                for i in range(0, len(items) - n + 1):
                    out.append(" ".join(items[i : i + n]).strip())
            return out

        phrases.extend(ngrams(search_tokens, 2, 4))

        deduped: list[str] = []
        seen: set[str] = set()
        for item in phrases:
            item = re.sub(r"\s+", " ", (item or "").strip())
            if item and item not in seen:
                seen.add(item)
                deduped.append(item)

        return SearchQuery(
            original=original,
            normalized=normalized,
            search_form=search_form,
            tokens=tokens,
            search_tokens=search_tokens,
            phrases=deduped,
        )
