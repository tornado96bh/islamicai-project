from __future__ import annotations

from pathlib import Path
import json
import os

from packages.learning.dictionary import search_form_text
from packages.learning.embeddings import EmbeddingBuilder

from .models import build_page_hit, hit_key

class SemanticSearcher:
    def __init__(self, storage_dir: str | Path | None = None):
        default_storage = Path(__file__).resolve().parents[2] / "storage" / "learning"
        self.storage_dir = Path(storage_dir) if storage_dir else default_storage
        self.embedding = EmbeddingBuilder(dimension=256)
        self.page_index_path = self.storage_dir / "page_embeddings.json"
        self.collection = os.getenv("QDRANT_COLLECTION", "islamicai_pages")
        self.qdrant_url = os.getenv("QDRANT_URL") or f"http://localhost:{os.getenv('QDRANT_PORT', '6333')}"
        self.timeout = max(1, int(float(os.getenv("QDRANT_TIMEOUT", "15"))))
        self._profiles: list[dict] = []
        self._loaded = False
        self._qdrant = None
        self._load()

    def _load(self) -> None:
        if self._loaded:
            return
        self._loaded = True

        if self.page_index_path.exists():
            try:
                payload = json.loads(self.page_index_path.read_text(encoding="utf-8"))
                self._profiles = payload.get("pages", []) or []
            except Exception:
                self._profiles = []

        try:
            from qdrant_client import QdrantClient
            self._qdrant = QdrantClient(url=self.qdrant_url, timeout=self.timeout)
        except Exception:
            self._qdrant = None

    def _local_search(self, query: str, limit: int) -> list[dict]:
        qvec = self.embedding.vectorize_text(query)
        hits: list[dict] = []
        for profile in self._profiles:
            vector = profile.get("vector") or []
            if not vector:
                continue
            score = self.embedding.similarity(qvec, vector)
            if score <= 0:
                continue
            hit = build_page_hit(profile, score, "semantic", "local-embedding")
            hits.append(hit)
        hits.sort(key=lambda x: x["score"], reverse=True)
        return hits[:limit]

    def _qdrant_search(self, query: str, limit: int) -> list[dict]:
        if self._qdrant is None:
            return []

        qvec = self.embedding.vectorize_text(query)
        try:
            rows = self._qdrant.search(
                collection_name=self.collection,
                query_vector=qvec.values,
                limit=limit,
                with_payload=True,
            )
        except Exception:
            return []

        hits: list[dict] = []
        for row in rows:
            payload = row.payload or {}
            profile = {
                "page_id": str(row.id),
                "page_number": payload.get("page_number"),
                "volume_id": payload.get("volume_id"),
                "volume_number": payload.get("volume_number"),
                "edition_id": payload.get("edition_id"),
                "edition_number": payload.get("edition_number"),
                "book_id": payload.get("book_id"),
                "book_title": payload.get("book_title"),
                "sample_text": payload.get("sample_text", ""),
            }
            hit = build_page_hit(profile, float(row.score or 0.0), "semantic", "qdrant")
            hits.append(hit)
        return hits

    def search(self, query: str, limit: int = 20) -> list[dict]:
        q = search_form_text(query)
        if not q:
            return []

        hits = self._qdrant_search(q, max(limit * 2, 20))
        if not hits:
            hits = self._local_search(q, max(limit * 2, 20))

        deduped: list[dict] = []
        seen: set[str] = set()
        for hit in hits:
            key = hit_key(hit)
            if key in seen:
                continue
            seen.add(key)
            deduped.append(hit)

        deduped.sort(key=lambda x: x["score"], reverse=True)
        return deduped[:limit]
